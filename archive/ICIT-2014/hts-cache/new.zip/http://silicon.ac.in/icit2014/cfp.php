<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script> 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
<!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//-->
 
  <!--header close-->

  <div class="menu">
    <div class="left-box1">
      <p class="ptext1">Organizing Committee</p>
	  <ul>
<b>General Chairs:</b><BR>

Saraju P. Mohanty<BR>
<font color="blue" size="2">University of North Texas, USA</font><BR>
R. K. Patnaik <BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar</font> <BR>

<b>Program Chairs: </b><BR>
Mahadevan Gomathisankaran<BR>
<font color="blue" size="2">University of North Texas, USA</font><BR>
B. S. Panda,<BR>
<font color="blue" size="2">Indian Institute of Technology (IIT) Delhi</font><BR>

<b>Publication Chairs:</b><BR>
Prasun Ghosal<BR>
<font color="blue" size="2">Indian Institute of Engineering Science& Technology,Shibpur</font><BR>
Niranjan Ray, <BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar</font><BR>

<b>Finance Chairs:</b><BR>
Ajit K. Behera, <BR>
<font color="blue" size="2">Orissa Information Technology Society (OITS)</font><BR>
Rudra Mohan Tripathy, <BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar </font><BR>

<b>Web Chair:</b><BR>
Umasankar Das<BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar</font> <BR>

<b>Publicity Chairs:</b><BR>
Souvik Ray,<BR> 
<font color="blue" size="2">ShareThis Inc., USA</font><BR>
Shanq-Jang Ruan, <BR>
<font color="blue" size="2">National Taiwan University of Science & Technology, Taiwan</font><BR>
Bijan Bihari Mishra, <BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar</font><BR>

<b>Local Arrangement Chairs:</b><BR>
Dipak K. Misra,<BR>
<font color="blue" size="2">Xavier Institute of Management, Bhubaneswar </font><BR>
Ashok K. Tripathy, <BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar</font><BR>

<b>Registration Chairs:</b><BR>
Debasmitha Pradhan and Debabrata Kar <BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar</font><BR>

<b>Advisors</b><BR>
S. P. Misra<BR>
<font color="blue" size="2">Orissa Information Technology Society</font><BR>
S. Padhy<BR>
<font color="blue" size="2">The Institute of Mathematics and Applications (IMA) Bhubaneswar</font><BR>
Durga Mishra,<BR>
<font color="blue" size="2">New Jersey Institute of Technology Newark, USA</font><BR>
Prasant Mohapatra, <BR>
<font color="blue" size="2">University of California Davis, USA</font><BR>
L. N. Bhuyan<BR>
<font color="blue" size="2">University of California Riverside, USA</font><BR>
Srikanth Sundararajan<BR>
<font color="blue" size="2">Indian Institute of Technology (IIT) Bhubaneswar</font><BR>
B. K. Das<BR>
<font color="blue" size="2">ITM University, New Delhi</font><BR>
Debatosh Guha<BR>
<font color="blue" size="2">IEEE Kolkata Section</font><BR>

<b>Patrons </b><BR>
N. G. Dhall, S. K. Nayak and R. Mishra<BR>
<font color="blue" size="2">Silicon Institute of Technology, Bhubaneswar</font>
	  
	  </ul>
	</div>
	
<div id="center-boxE">
<!--
<p align="right">[<a href="ICIT2014_CFP.pdf">CFP- Download</a>]</p> //-->
<center>
<h2>ICIT 2014</h2>
<h3>13<sup>th</sup> International Conference on Information Technology, </h3>
<h4>22nd -24th December, 2014, Bhubaneswar, India.</h4><BR>
<h3>Call for Papers</h3>
</center>
<BR>
<p align="justify">
International Conference on Information Technology (ICIT) is a premier international forum for high quality research in the areas of Information Technology. The 13th ICIT, ICIT 2014 is being jointly organized by the Orissa Information Technology Society (<a href="http://www.oits.org">http://www.oits.org</a>) and Silicon Institute of Technology, Bhubaneswar, India (<a href="http://www.silicon.ac.in">http://www.silicon.ac.in</a>). Researchers, developers, and practitioners from academia and industry are invited to present their research findings on various topics of IT and its applications. <!-- The proceedings of the ICIT 2014 will be published by IEEE-CS-CPS and will be indexed in IEEE Xplore. //-->
</p><BR>
<p align="justify">
ICIT-2014encourages submissions in all the areas of information technology. However, the papers in the following 7 tracks will be primary focus of ICIT 2014:               
</p><BR>
<ol>
<li><b>Sequential, Parallel and Distributed Computing (SPD):</b> Analysis and Design of exact and approximation algorithms, Parallel and Distributed Computing, Load balancing and partitioning, Cloud Computing, Parallel and Distributed algorithms in Data Mining and Computational Biology. Multi-cores, memory hierarchy, multiprocessor synchronization and debugging, concurrent programming, OS virtualization modeling and simulation, load balancing and partitioning, compiler techniques.</li><BR>
<li><b>Bioinformatics and Computational Biology (BCB):</b> Novel applications in Bioinformatics, Data Mining and Statistical Modeling of biological data, Visualization of Biological Processes and Data,  Management, Migration and Integration of Biological Databases, Biological Database search, indexing  and access.</li><BR>
<li><b>Communication Networks and Protocols (CNP):</b> Broadband Multimedia Communications, Wireless Ad hoc/ Sensor Networks, Wireless and Mobile Communications, Emerging Information Technology Networks, Vehicular ad-hoc network, Optical Fiber/ Microwave communication, Peer-to-peer, overlay, and content distribution networks, Energy- and power-aware communication.</li><BR>
<li><b>Language Processing and Industry Applications (LPA) :</b>  Character recognition, text to speech conversion, speech synthesis, Signal and Image Processing, requirements engineering, human-computer interface, software testing, real time software, Web services, search engine design, page ranking algorithms, web-page prediction, ontology, agent technology, crawler design, Multimedia Systems and Applications.</li><BR>
<li><b>Information Security, Content Protection, and Digital Rights Management (DRM):</b> Watermarking, Steganography, Cryptography, Biometrics, Digital Libraries, Network Security, Computer Security, Ontologies and Reasoning, Applications of Semantic Web and Linked Data, Semantic Web Architecture Social Semantic Web, Biometric Authentication.</li><BR>
<li><b>Databases, Information Warehousing and Data Mining (DWM):</b>  Intelligent Databases, Query and Constraint-based Data Mining, Mining Spatial and Temporal Data, Mining of Data Streams, Feature Extraction, Collaborative filtering/personalization, Cost-based Decision making, Visual Data Mining, Privacy Sensitive Data Mining, graph Data mining, Metadata and Meta modeling.</li><BR>
<li><b>Application Specific Software and Hardware Systems (ASH):</b> Embedded Information Systems, Hardware/Software/Firmware issues, Nanotechnology and Applications, Quantum Information Processing, application specific systems, hardware design, electronic design automation, network-on-a-chip.   </li><BR>
</ol>
<p align="justify">
<b>PAPER SUBMISSION:</b> Manuscripts offering high quality original and unpublished research, case studies and implementations are solicited. The manuscripts need to be formatted as a double column conference format. The maximum length of the manuscript needs to be of 6-pages. All submitted papers will undergo DOUBLE-blind-review by the program committee. Authors need to prevent identity disclosure by: (1) not listing names and affiliations of the authors on the manuscript, (2) not saying "my work" or "our work" in the text while citing self-references, and (3) not writing acknowledgments in such a way that identity of authors are implied. Author information should only be included in the submission form. Manuscripts not following this requirement or exceeding 6-page length will be rejected without review. Authors need to submit a single pdf file of each manuscript at: <a href="https://www.easychair.org/conferences/?conf=icit2014">https://www.easychair.org/conferences/?conf=icit2014</a>. ICIT 2014 will follow strict no-show policy, i.e. an accepted paper needs to be registered and presented,and otherwisethe paper will be removed from the proceedings.
</p><BR>
<center>
<font color="red"><b>Important Deadlines</b></font><BR>
</center>
Paper Submission: <font color="red"><strike>25th June, 2014</strike> 15th July, 2014</font><BR>
Authors Notification:25th August, 2014<BR>
Camera Ready and Registration:8th September, 2014<BR>

	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
