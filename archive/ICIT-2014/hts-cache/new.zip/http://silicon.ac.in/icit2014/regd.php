<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
 <!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//--> 
  <!--header close-->

  <div class="menu">
 <!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
<div id="center-boxE">
<!-- About CP //-->
<center><h3>Registration</h3></center><BR><BR>
<b>Registration for ICIT 2014</b><BR>
<p align="justify">
You have to register ONLINE for ICIT 2014. The conference registration fee includes: 
</p><BR>
<ul>
<li>Participation to all conference technical sessions </li>
<li>Cost of publication of one paper includes lunch, tea, and snacks. </li>
</ul>
<br>
<b>Registration Fee</b><BR>
<table border="1">
<tr>
<td><b>Category</b></td>
<td><b>SAARC (India, Nepal, Sri Lanka, Pakistan, Bangladesh, Bhutan, Burma)</b></td>
<td><b>Other Countries</b></td>
</tr>
<tr>
<td>Researcher/Academician</td>
<td>INR 8,000</td>
<td>USD 300</td>
</tr>
<tr>
<td>Student</td>
<td>INR 6,500</td>
<td>USD 200</td>
</tr>
<tr>
<td>Professional Members <!-- (IEEE/CSI/ISTE/OITS) //--></td>
<td>INR 6,500</td>
<td>USD 200</td>
</tr>
<tr>
<td>Industry Professionals</td>
<td>INR 10,000</td>
<td>USD 400</td>
</tr>
</table>
<BR>
<b>Mode of Payment of Registration Fee:</b> Online Transfer through Internet Banking (Foreign Authors must make the payment in USD adding the wire transfer charges over the Registration Fees).
<BR>
<font color="red"><strong>Note :</strong></font>
<BR>
1.<i>If you have any query regarding registration, kindly feel free to mail us at debabrata.kar@silicon.ac.in (or) contact the Registration Chair (+91-9438149719).</i>
<BR><BR>
2.<i>Prior to Registration, transfer the Registraton Fees and keep the Transaction Reference Number ready.</i><BR><BR>
3.<i>Student/Professional Member need to attach the scanned copy of the proof of studentship / Professional Membership (PDF format). </i>
<BR>
<p align="right"><b><a href="regdonline.php"><img src="register.png" alt="Register Online" onmouseover="this.src='rr.png';" onmouseout="this.src='register.png';"></a></b></p>
<BR>
                <dl>
<b>Bank Address:</b><BR>
					
						State Bank of India <BR>
						Infocity Branch, Bhubaneswar<BR>
						IDCO Building Infocity Campus<BR>
						Chandaka Industrial Estate<BR><BR>
						<strong>Account Name:</strong> ICIT 2014<BR>
						<strong>Account Number:</strong> 33812148497<BR>
						<strong>Branch Code:</strong> 10133<BR>
						<strong>Brach Phone:</strong> 2743339<BR>
						<strong>IFSC:</strong> SBIN0010133<BR>
						<strong>MICR:</strong> 751002030<BR>			
					
				
<!-- About CP //-->
	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
