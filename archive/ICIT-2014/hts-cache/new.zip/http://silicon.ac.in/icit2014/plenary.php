<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
 <!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//--> 
  <!--header close-->

  <div class="menu">
 <!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
<div id="center-boxE">
<!-- About CP //-->
<table width="100%">
<tr>
<td>
<center>
<strong><h3>Discovery of the Human Protein Interactome</h3></strong>
<BR><BR>

Madhavi K. Ganapathiraju<BR>
Department of Biomedical Informatics<BR>
University of Pittsburgh, Pittsburgh, PA 15213<BR>
Email:madhavi@pitt.edu<BR>
</center>
<BR><BR>
<strong>Abstract:</strong><BR>
<p align="justify">
With advances in high-throughput sequencing and relevant computational techniques, the genetic basis for a number of diseases is being revealed. The network of protein-protein interactions, or the interactome, allows us to understand the molecular mechanisms by which these genesrelate to the specific diseases.  Here, I present our work on the discovery of the interactome using computational methods. There are massive volumes and varieties of partially characterized data related to this problem. Traditional approaches to modeling the data are not possible. We have developed suitable machine learning approaches to solve the open challenges in this domain, and predicted of interactions accurately for several genes. These predictions are advancing biology research: an example is the interaction between two genes OASL and RIG-I, which when studied further by experimental methods, led to the discovery that boosting a naturally occurring protein OASL may help the body to detect and fend off certain viral infections on its own. Such translation of the hundreds of predicted interactions to biology requires large scale coordinated human interactions through experts. We are using the web for collecting and authenticating such expert knowledge through crowd sourcing and for disseminating the novel predictions to suitable biologists.
</p>
<BR>
</td>
</tr>
<tr>
<td><strong>Speaker Biography:</strong></td>
</tr>
<tr>
<td>
<table>
 <tr>
  <td width="30%"><img src="images/madhavi.jpg"></td>
  <td>
  <p align="justify">
Madhavi Ganapathiraju received Ph.D. from Carnegie Mellon University School of Computer Science in 
Language and Information Technologies and M.Engg.degree from Indian Institute of Science in Electrical 
Communications Engineering.  She is a graduate of A.R.S.D. College of Delhi University where she obtained B.S. 
in Electronics, Physics and Mathematics.  She is currently Assistant Professor at the Department of Biomedical 
Informatics of University of Pittsburgh School of Medicine. She holds secondary appointments at Intelligent 
Systems Program of University of Pittsburgh School of Arts and Sciences and Molecular and Cellular Cancer 
Biology Program of University of Pittsburgh Cancer Institute.She holds adjunct appointment at Language 
Technologies Institute of Carnegie Mellon University School of Computer Science. She is a Faculty of 
Biomedical Informatics Training Program (<a href="http://www.dbmi.pitt.edu" target="_blank">www.dbmi.pitt.edu</a>), Intelligent Systems Program (<a href="http://www.isp.pitt.edu" target="_blank">www.isp.pitt.edu</a>), 
Joint CMU-Pitt Computational Biology Program (www.compbio.cmu.edu) and Integrated Systems Biology Program(<a href="http://www.isb.pitt.edu" target="_blank">www.isb.pitt.edu</a>) 
of University of Pittsburgh. She is on the Advisory Board of Biotechnology Innovation and Computing Program (<a href="http://bic.cs.cmu.edu" target="_blank">http://bic.cs.cmu.edu</a>) 
of Carnegie Mellon University. Her current research isfunded by the Biobehavioral Research Awards for Innovative New Scientists 
(BRAINS) grant from National Institute of Mental Health of the National Institutes of Health, USA. Her publications may be 
viewed at <a href="http://tinyurl.com/MadhaviCMUscholar" target="_blank">http://tinyurl.com/MadhaviCMUscholar</a>
  </p>
  </td>
 </tr>
</table>
</td>
</tr>
</table>
<table width="100%">
<tr>
<td>
<center>
<strong><h3>iSECURE: Integrating Learning Resources for Information Security Research and Education</h3></strong>
<BR><BR>

Vincent Oria<BR>
Department of Computer Science Department<BR>
New Jersey Institute of Technology<BR>
Email:vincent.oria@njit.edu<BR>
</center>
<BR><BR>
<strong>Abstract:</strong><BR>
<p align="justify">
This talk focuses on the iSECURE project, a research-in-progress that investigates methods and procedures for linking and integrating multi-media teaching materials (slides, videos and textbooks) for use in Information Security courses based on a security ontology. The semantic linking of multimedia materials allows students to search and compose multimedia and interactive course materials based on the digital contents, methods and learning styles, thus enabling flexible personalized learning. To achieve these goals, the project seeks to analyze, develop, and assess the following related research tasks: (1) Segmenting and annotating learning media based on their learning content, (2) Building a security ontology to be used for annotating and querying the learning objects, (3) Adapting lecture contents to student learning styles, and (4) Evaluating the usability and effectiveness of the linked multimedia learning system.
</p>
<BR>
<p align="justify">
This NSF-funded research project involves collaboration among multiple institutions, namely, NJIT (Vincent Oria, Reza Curtmola, Jim Geller), CUNY College of Staten Island (Soon Ae Chun), and Montclair State University (Edina Renfro-Michel).
</p>
</td>
</tr>
<tr>
<td><strong>Speaker Biography:</strong></td>
</tr>
<tr>
<td>
<table>
 <tr>
  <td width="30%"><img src="images/oria.jpg"></td>
  <td>
  <p align="justify">
  Vincent Oria is an associate professor of computer science at the New Jersey 
  Institute of Technology (NJIT). His research interests includes multimedia 
  databases, spatio-temporal databases and recommender syatems. He has 
  held visiting professor positions at various institutions including 
  National Institute of Informatics (Tokyo, Japan), Telecom-PariTech(Paris, France), 
  University de Paris-IX Dauphine (Paris, France), INRIA (Roquencourt, France), 
  Conservatoire National des Arts et Metiers (Paris, France), Chinese University 
  of Hong Kong (Hong Kong, China) and University de Bourgogne (Dijon, France). 
  He received the 2014 Outstanding Achievement in Research Award for the NJIT 
  College of Computing Sciences.
  </p>
  </td>
 </tr>
</table>
</td>
</tr>
</table>

<table width="100%">
<tr>
<td>
<center>
<strong><h3>Purchasing Electronic Database and E-Collections for Library:
A Framework for a Multi-level and Multi CriteriaEvaluation and Selection
</h3></strong>
<BR><BR>

Cheickna Sylla<BR>
School of Management<BR>
New Jersey Institute of Technology (NJIT), USA<BR>
Email: sylla@adm.njit.edu<BR>
</center>
<BR><BR>
<strong>Abstract:</strong><BR>
<p align="justify">
The problem of selecting the optimal packages of databases and related e-materials for a library is very complex due the ever changing nature of information system resources, the multiple conflicting goals, and the needs of the university faculty and students. In addition, library resources are intended for sharing to support faculty research network across multiple disciplines. Clearly, factors related to faculty collaboration in both face-to-face and virtual modes must be accounted for in the resource sharing model. Thus, problem not only involves multiple factors and multiple decision makers, but also multiple-decision levels for budget allocation and resource sharing constraints. This research proposes a modelling framework merging a multi-level/multi-divisional and multi-criteria models integrating capital budgeting, the knapsack problem, network optimization and AHP models to help multiple decision makers in their evaluation and selection decision. The framework offers a 3-step methodology based on the multifaceted combination of inter-related models to derive the best set of e-databases, e-journals and other applicable online resources subject to the budget, resources sharing rules and other university restrictions.
</p>
</td>
</tr>
<tr>
<td><strong>Speaker Biography:</strong></td>
</tr>
<tr>
<td>
<table>
 <tr>
  <td width="30%"><img src="images/sylla.jpg"></td>
  <td>
  <p align="justify">
   	Dr. Cheickna Sylla is a Professor of Decision Sciences and MIS at the School of Management, New Jersey Institute of Technology, Newark, New Jersey. He holds a Ph.D. in Industrial Engineering from SUNY at Buffalo, Buffalo, New York. His teaching and research interests include: statistical analyses and applied operations research methods to human machine interfaces studies, project management, distribution logistics, management information systems, decision support systems, and operations management. His research publications appear in IEEE Transactions in Systems, Man and Cybernetics, IEEE Transactions on Engineering Management, European Journal of Operations Research, Computers & Industrial Engineering,ControlEngineering
Practice, and Cost Management, International Journal of Management and Decision Making, International Journal of Information Technology and Management, International Journal of Networking and Virtual Organizations, International Academy of Business and Economics, and International Environmental Agreements: Politics, Law and Economics, etc. He published numerous articles in conference proceedings. He is a member of INFORMS, IIE, and Production & Operations Management Society. He has been involved in developing and teaching business statistics and data analysis courses at both undergraduate and graduate levels for over 20 years.

  </p>
  </td>
 </tr>
</table>
</td>
</tr>
</table>

<table width="100%">
<tr>
<td>
<center>
<strong><h3>Characterizing Virality on Twitter</h3></strong>
<BR><BR>

Amitabha Bagchi<BR>
Department of Computer Science and Engineering<BR>
Indian Institute of Technology, Delhi<BR>
Email: bagchi@cse.iitd.ac.in<BR>
</center>
<BR><BR>
<strong>Abstract:</strong><BR>
<p align="justify">
The emergence of online social networks and, with them, the phenomenon of "virality" wherein certain themes or pieces of content (or memes as they are known) spread explosively through the network, has attracted a lot of attention from computer science researchers in the last few years. The central problem in this area can be posed as a simple question: Can we predict which meme will go viral before it has actually gone viral? We began studying this problem by trying to identify metrics that discriminate between viral and non-viral topics and followed up by trying to actually solve the prediction problem. In this talk we will present some of the challenges that we encountered along the way and some of the results we obtained.
</p>
</td>
</tr>
<tr>
<td><strong>Speaker Biography:</strong></td>
</tr>
<tr>
<td>
<table>
 <tr>
  <td width="30%"><img src="images/amitav.jpg"></td>
  <td>
  <p align="justify">
   	Amitabha Bagchi earned his Ph.D. in 2002 from Johns Hopkins University. His research interests range from network algorithms and data structures to the applications of random graph theory to wireless networks. Over the last few years he has been focusing on applying ideas from complex systems and stochastic processes to online social networks in a data-driven setting.  Amitabha is an Associate Professor in the Computer Science and Engineering Department at IIT Delhi where he is a member of the nascent Data Sciences group.

  </p>
  </td>
 </tr>
</table>
</td>
</tr>
</table>
<!-- About CP //-->
	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
