<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
 <!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//--> 
  <!--header close-->

  <div class="menu">
 <!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
<div id="center-boxE">
<center>
<h2>ICIT-2014</h2>
<h3>13<sup>th</sup> International Conference on Information Technology, </h3>
<h4>Bhubaneswar, India, December 22nd -24th, 2014.</h4><BR>
<h3>Program Committee</h3>
</center>
<BR>
<table width="100%">
<tr>
<td><strong>Track - Sequential, Parallel and Distributed Computing (SPD)</strong></td>
</tr>
<tr>
<td>
<table width="95%">
<tr>
<td>Nabanita Das (Track Chair)</td>
<td>Indian Statistical Institute (ISI), India</td>
</tr>
</table>
<table width="95%">
 <tr>
  <td>
	<h4><center>TPC Members</center></h4>
<img src="tiny.jpg">&nbsp;&nbsp;Arobinda Gupta, Indian Institute of Technology, Kharagpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Bhabani P. Sinha, Indian Statistical Institute<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Goutam Chakraborty, Iwate Prefectural University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Krishna M. Shivalingam, IIT, Chennai<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Krishnendu Mukhopadhyaya, Indian Statistical Institute<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Pradip K. Srimani, Clemson University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Shikharesh Majumdar, Carleton University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Subhas C. Nandy, Indian Statistical Institute<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Subhasis Bhattacharjee, Synopsys<BR>






  </td>
 </tr>
</table>	
</td>
</tr>
</table>


<table width="100%">
<tr>
<td><strong>Track - Bioinformatics and Computational Biology (BCB)</strong></td>
</tr>
<tr>
<td>
<table width="95%">
<tr>
<td>Ananth Kalyanaraman (Track Chair)</td>
<td>Washington State University, USA</td>
</tr>
</table>
<table width="95%">
 <tr>
  <td>
	<h4><center>TPC Members</center></h4>
<img src="tiny.jpg">&nbsp;&nbsp;Debnath Pal, Indian Institute of Science<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Inna Rytsareva, Washington State University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Jaroslaw Zola, Rutgers Discovery Informatics Institute<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Turbo Majumder, Indian Institute of Technology Delhi<BR>


  </td>
 </tr>
</table>	
</td>
</tr>
</table>

<table width="100%">
<tr>
<td><strong>Track - Communication Networks and Protocols (CNP)</strong></td>
</tr>
<tr>
<td>
<table width="95%">
<tr>
<td>Prasun Ghosal  (Track Chair)</td>
<td>IIEST, Shibpur, India</td>
</tr>

<tr>
<td>Chen-Yu Lee  (Track Chair)</td>
<td>University of North Texas</td>
</tr>

<tr>
<td>Bighnaraj Panigrahi  (Track Chair)</td>
<td>TCS Innovation Labs, Bangalore, India</td>
</tr>
</table>
<table width="95%">
 <tr>
  <td>
	<h4><center>TPC Members</center></h4>

<img src="tiny.jpg">&nbsp;&nbsp;Abhijit Chandra, IIEST, Shibpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Abhirup Das Barman, University of Calcutta<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Anirban Kundu, Netaji Subhash Engineering College<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Ashik Paul, University of Calcutta<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Bhaskar Sardar, Jadavpur University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Brajendra Nath Panda, University of Arkansas<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Chandreyee Chowdhury, Jadavpur University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Goutam Das, IIT Kharagpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Jibitesh Mishra, College of Engineering & Technology Bhubaneswar<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Mridul Sankar Barik, Jadavpur University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Mrinal Kanti Naskar, Jadavpur University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Parama Bhaumik, Jadavpur University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Prabin Kumar Padhy, Indian Institute of Information Technology, Design and Manufacturing Jabalpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Rakesh Balabantaray, IIIT Bhubaneshwar<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Samrat Sabat, University of Hyderabad<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sanjay Dhar Roy, NIT, Durgapur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Santi Prasad Maity, IIEST, Shibpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sarbani Roy, Jadavpur University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sateesh Kumar Peddoju, Indian Institute of Technology, Roorkee<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sipra Das Bit, IIEST, Shibpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Souvik Ray, ShareThis Inc.<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sukanta Das, IIEST, Shibpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sumit Kundu, NIT, Durgapur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Tamaghna Acharya, IIEST, Shibpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Vaskar Raychoudhury, IIT Roorkee<BR>



  </td>
 </tr>
</table>	
</td>
</tr>
</table>

<table width="100%">
<tr>
<td><strong>Track - Language Processing and Industry Applications (LPA) </strong></td>
</tr>
<tr>
<td>
<table width="95%">
<tr>
<td>Niladri Chatterjee  (Track Chair)</td>
<td>Indian Institute of Technology Delhi, India</td>
</tr>
</table>
<table width="95%">
 <tr>
  <td>
	<h4><center>TPC Members</center></h4>
<img src="tiny.jpg">&nbsp;&nbsp;Asif Eqbal, Indian Institute of Technology Patna<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Devika Madalli, Documentation Research and Training Centre Indian Statistical Institute<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Mohammed Abulaish, Jamia Millia Islamia<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Pinaki Mitra, Indian Institute of Technology Guwahati<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Pushpak Bhattacharya, Indian Institute of Technology Bombay<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Ramesh Agarwal, Jawaharlal Nehru University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sanghamitra Mohanty, Utkal University, Bhubaneshwar<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sanjay Kadam, Centre for Development of Advanced Computing<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sivaji Bandyopadhyay, Jadavpur University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sung-Kook Han, Won Kwang University, South Korea<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Umapada Pal, Indian Statistical Institute<BR>





  </td>
 </tr>
</table>	
</td>
</tr>
</table>


<table width="100%">
<tr>
<td><strong>Track - Information Security, Content Protection, and Digital Rights Management (DRM)</strong></td>
</tr>
<tr>
<td>
<table width="95%">
<tr>
<td>Sriram Chellppan (Track Chair)</td>
<td>Missouri University of Science and Technology, USA</td>
</tr>
</table>
<table width="95%">
 <tr>
  <td>
	<h4><center>TPC Members</center></h4>
<img src="tiny.jpg">&nbsp;&nbsp;Akhilesh Tyagi, Iowa State University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;I-Ling Yen, University of Texas at Dallas<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Mark Snyder, Expedia<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Neelanjana Dutta, Jasper Wireless<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Padmalochan Bera, Indian Institute of Technology Bhubaneshwar<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Satyajeet Nimgaonkar, University of North Texas<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Vimal Kumar, University of West Florida<BR>



  </td>
 </tr>
</table>	
</td>
</tr>
</table>


<table width="100%">
<tr>
<td><strong>Track - Databases, Information Warehousing and Data Mining (DWM)</strong></td>
</tr>
<tr>
<td>
<table width="95%">
<tr>
<td>Prashant Kumar Patra (Track Chair)</td>
<td>College of Engineering & Technology Bhubaneswar, India</td>
</tr>
</table>
<table width="95%">
 <tr>
  <td>
	<h4><center>TPC Members</center></h4>
<img src="tiny.jpg">&nbsp;&nbsp;Andrews Samraj, Multimedia University Melaka Malaysia<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Bijan Misra, Silicon Institute of Technology<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Debajyoti Mukhopadhyay, Maharashtra Institute of Technology<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Garima Thakral, Oriental University, Indore, India<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Gautam Das, University of Texas at Arlington<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Nabendu Chaki, University of Calcutta<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Nita Parekh, International Institute of Information Technology, Hyderabad<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Prakash Duraisamy, Old Dominion University<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Ruma Dutta, Netaji Subhash Engineering College<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sanghamitra Bandyopadhyay, Indian Statistical Institute<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sanjukta Bhowmick, University of Nebraska at Omaha<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Saumyadipta Pyne, CR Rao Advanced Institute of Mathematics, Statistics and Computer Science<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Susanta Mitra, Adamas Institute of Technology<BR>




  </td>
 </tr>
</table>	
</td>
</tr>
</table>

<table width="100%">
<tr>
<td><strong>Track - Application Specific Software and Hardware Systems (ASH)</strong></td>
</tr>
<tr>
<td>
<table width="95%">

<tr>
<td>Yier Jin (Track Chair)</td>
<td>University of Central Florida</td>
</tr>

<tr>
<td>B. Venkataramani (Track Chair)</td>
<td>National Institute of Technology Trichy, India</td>
</tr>
</table>
<table width="95%">
 <tr>
  <td>
	<h4><center>TPC Members</center></h4>
<img src="tiny.jpg">&nbsp;&nbsp;Anirban Sengupta, Indian Institute of Technology, Indore<BR>	
<img src="tiny.jpg">&nbsp;&nbsp;Debi Prasad Das, CSIR - Institute of Minerals and Materials Technology<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Dhruva Ghai, Oriental University, Indore, India<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Jawar Singh, Indian Institute of Information Technology, Design and Manufacturing Jabalpur<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Mamatha Samson, IIIT Hyderabad<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Manoranjan Satpathy, Indian Institute of Technology Bhubaneshwar<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Oghenekarho Okobiah, University of North Texas<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Preeti Ranjan Panda, Indian Institute of Technology Delhi<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sourav Roy, Freescale Semiconductor, Inc.<BR>
<img src="tiny.jpg">&nbsp;&nbsp;Sujay Deb, IIIT Delhi<BR>


  </td>
 </tr>
</table>
</td>
</tr>
</table>


	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
