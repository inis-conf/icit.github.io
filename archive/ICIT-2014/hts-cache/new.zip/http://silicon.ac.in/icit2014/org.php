
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
 <!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//--> 
  <!--header close-->

  <div class="menu">
 <!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
<div id="center-boxE">
<center>
<h2>ICIT-2014</h2>
<h3>13<sup>th</sup> International Conference on Information Technology, </h3>
<h4>Bhubaneswar, India, December 22nd -24th, 2014.</h4><BR>
<h3>Organizing Committee</h3>
</center>
<BR>
<h5>General Chairs:</h5>
<ul>
<li><strong>Saraju P. Mohanty</strong>, University of North Texas, USA, saraju.mohanty@unt.edu</li>
<li><strong>R. K. Patnaik</strong>, Silicon Institute of Technology, rkp@silicon.ac.in</li>
</ul>
<BR><h5>Program Chairs: </h5>
<li><strong>Mahadevan Gomathisankaran</strong>, University of North Texas, USA, mahadevan.gomathisankaran@unt.edu</li>
<li><strong>B. S. Panda</strong>, Indian Institute of Technology (IIT) Delhi, bspanda@maths.iitd.ac.in</li>
<BR><h5>Publication Chairs:</h5>
<li><strong>Prasun Ghosal</strong>, Indian Institute of Engineering Science and Technology, Shibpur, prasung@gmail.com</li>
<li><strong>Niranjan Ray</strong>, Silicon Institute of Technology, niranjan@silicon.ac.in</li>
<BR><h5>Finance Chairs:</h5>
<li><strong>Ajit K. Behera</strong>, Orissa Information Technology Society (OITS), ajitcs@silicon.ac.in</li>
<li><strong>Rudra Mohan Tripathy</strong>, Silicon Institute of Technology, rudra@silicon.ac.in</li>
<BR><h5>Web Chair:</h5>
<li><strong>Umasankar Das</strong>, Silicon Institute of Technology, umasankar@silicon.ac.in</li>
<BR><h5>Publicity Chairs:</h5>
<li><strong>Souvik Ray</strong>,  ShareThis Inc., USA, rsouvik@gmail.com</li>
<li><strong>Shanq-Jang Ruan</strong>, National Taiwan University of Science & Technology, Taiwan, sjruan@mail.ntust.edu.tw</li>
<li><strong>Bijan Bihari Mishra</strong>, Silicon Institute of Technology, bijan@silicon.ac.in</li>
<BR><h5>Local Arrangement Chairs:</h5>
<li><strong>Dipak K. Misra</strong>, Xavier Institute of Management (XIMB), Bhubaneswar & OITS, dipak@ximb.ac.in</li>
<li><strong>Ashok K. Tripathy</strong>, Silicon Institute of Technology, tripathy_1948@sify.com</li>
<BR><h5>Registration Chairs:</h5>
<li><strong>Debasmita Pradhan</strong>, Silicon Institute of Technology, debasmita@silicon.ac.in</li>
<li><strong>Debabrata Kar</strong>, Silicon Institute of Technology, debabrata.kar@silicon.ac.in</li>
<BR><h5>Local Arrangement Committee:</h5>
<li><strong>Aurabinda Mishra</strong>, Silicon Institute of Technology, aurabinda@silicon.ac.in</li>
<li><strong>B. P. Choudhury</strong>, Silicon Institute of Technology, bhagwat@silicon.ac.in</li>
<li><strong>Saroj Kanta Mishra</strong>, Silicon Institute of Technology, drsaroj@silicon.ac.in</li>
<li><strong>Satyananda Champati Rai</strong> , Silicon Institute of Technology, satya@silicon.ac.in</li>
<li><strong>Pradipta K. Pattanayak</strong>, Silicon Institute of Technology, ppattanayak@silicon.ac.in</li>
<li><strong>Pradyumna Kumar Tripathy</strong>, Silicon Institute of Technology, ptripathy@silicon.ac.in</li>
<li><strong>Sushri Samita Rout</strong>, Silicon Institute of Technology, sushri@silicon.ac.in</li>
<li><strong>Pulak Sahoo</strong>, Silicon Institute of Technology, pulak.sahoo@silicon.ac.in</li>
<li><strong>Pamela Chaudhury</strong>, Silicon Institute of Technology, pamela@silicon.ac.in</li>
<li><strong>Samaleswari P. Nayak</strong>, Silicon Institute of Technology, samaleswari.nayak@silicon.ac.in</li>
<li><strong>Manoj K. Samantara</strong>, Silicon Institute of Technology, manojcs@silicon.ac.in</li>



<BR><h5>Advisors</h5>
<li><strong>S. P. Misra</strong>, Orissa Information Technology Society (OITS)</li>
<li><strong>S. Padhy</strong>, The Institute of Mathematics and Applications (IMA) Bhubaneswar</li>
<li><strong>Durga Mishra</strong>, New Jersey Institute of Technology Newark, USA</li>
<li><strong>Prasant Mohapatra</strong>, University of California Davis, USA</li>
<li><strong>L. N. Bhuyan</strong>, University of California Riverside, USA</li>
<li><strong>Srikanth Sundararajan</strong>, Indian Institute of Technology (IIT) Bhubaneswar</li>
<li><strong>B. K. Das</strong>,  ITM University, New Delhi</li>
<li><strong>Debatosh Guha</strong>, Chairman, IEEE Kolkata Section</li>
<BR><h5>Patrons</h5>
<li><strong>Nitai Gour Dhall</strong>, Silicon Institute of Technology</li>
<li><strong>Sanjeev K.Nayak</strong>, Silicon Institute of Technology</li>
<li><strong>Ramananda Mishra</strong>, Silicon Institute of Technology</li>

	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
