
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
 <!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//--> 
  <!--header close-->

  <div class="menu">
 <!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
<div id="center-boxE">
<!-- About CP //-->
<center><h3>Local Information</h3></center><br><br>
<p align="justify">
<h4>Venue:</h4><BR> 
Silicon Institute of Technology,<BR>
Silicon Hills, Patia<BR>
Bhubaneswar-751024<BR>
Odisha, India<BR>
Website: http://silicon.ac.in/sitbbsr/<BR><BR>

<h4>About Bhubaneswar</h4>

<p align="justify">
Bhubaneswar, the capital of Orissa, is also popularly known as the "Temple City of India". Being the seat of Tribhubaneswar or 'Lord Lingaraj', Bhubaneswar is an important Hindu pilgrimage centre. Hundreds of temples dot the landscape of the Old Town, which once boasted of more than 2000 temples. Bhubaneswar is the place where temple building activities of Orissan style flowered from its very inception to its fullest culmination extending over a period of over one thousand years.
</p><BR>
<p align="justify">
Bhubaneswar has emerged as knowledge hub in India, with several private and government colleges geared towards engineering, management, and other courses. Some of the reputed universities located at Bhubaneswar are: Utkal University,  Orissa University of Agriculture and Technology, Utkal University of Culture, KIIT University, International Institute of Information Technology, Institute of Life science, Centurion University and Siksha O Anusandhan University. Along with All India Institute of Medical Sciences, there are three other medical colleges, about 10 MBA colleges, 4 Pharmacy colleges and 60 Engineering colleges at Bhubaneswar.  Other educational institutions include the IIT Bhubaneswar, International Institute of Information Technology, Bhubaneswar (IIIT-Bh), Xavier Institute of Management (XIMB), Institute of Mathematics and Applications(IOMA), National Institute of Science Education and Research (NISER), National Institute of Fashion Technology (NIFT), Institute of Physics (IOP), Institute of Minerals and Materials Technology, Central Institute of Freshwater Aquaculture, Regional Medical Research Center and Regional Institute of Education.
</p><BR>
<p align="justify">
Bhubaneswar has around one thousand temples; and is known as the Temple City of India. Some of the famous temples include, Lingaraj Temple, Muktesvara Temple, Rajarani Temple, Ananta Vasudeva Temple. The twin hills of Khandagiri & Udayagiri, served as the site of an ancient Jain monastery which was carved into cave-like chambers in the face of the hill. Dhauli hills has major Edicts of Ashoka engraved on a mass of rock and a white Peace Pagoda has been built by the Japan Buddha Sangha and the Kalinga Nippon Buddha Sangha in the 1970s. Apart from the ancient temples, other important temples were built in recent times include Ram Mandir and ISKCON.
Bhubaneswar also has: the Odisha State Museum,  the Tribal Research Institute Museum, Nandankanan Zoological Park,  the State Botanical Garden  and Regional Plant Resource Center (Ekamra Kanan), Nicco Park and Ocean World, Pathani Samanta Planetarium, Regional Museum of Natural History, Regional Science Center and State Handicrafts Museum.
</p>
<div>
	<div>
	</div>	
</div> 
<br>
<p align="justify">
Key elements of Bhubaneswar's cuisine include rice and a fish curry known as machha jholo, which can be accompanied by desserts such as Rasagola, Rasabali, Chhena Gaja and Chhena Poda. Odisha's large repertoire of seafood dishes includes various preparations of lobsters and crabs brought in from Chilika Lake. Street foods such as Gupchup (a deep-fried crepe with tamarind sauce), Cuttack-chaat, Dahi bara-Aloo dum and Bara-ghuguni are sold all over the city. Traditional Oriya food such as Dahi-Pakhal (rice soaked in water with yogurt and seasonings) is considered as a body coolant, accompanied by Badi chura or saga are consumed during months of April-June.] The Abadha of Lingaraj Temple and Ananta Vasudeva Temple served for devotees is considered a vegetarian culinary delight. Other vegetarian dishes are Dalma (made of lentils and vegetables boiled together and then fried with other spices) and Santula (lightly spiced steamed vegetables). Sweets play a large part in the diet of Bhubaneswarites-especially at their social ceremonies. Bhubaneswar is known for its kora-khhaii which are made up of paddy, jaggery and coconut pieces. Pitha, a kind of sweet cake, bread or dim sum are winter specialties.
</p>
<p align="justify"><br>
The population of Bhubaneswar is around 10 lakh.  Temperature during December and January is 15-18 &deg;C (59-64 &deg;F).
</p>

<h3>Hotel Information:</h3>

Details of accommodation facilities will be updated soon<br><br>
<h3>Important Tourist Places:</h3>
<div class="mydiv">
    <img class="myimage" src="local/jagannath2.jpg"/>

<h4>Puri Jagannath</h4>
	<p>The temple of Lord Jagannath ('Lord of the Universe') at Puri is one of the most sacred pilgrimage spots in India, one of the four abodes (dhamas) of the divine that lie on the four directions of the compass. The present temple structure was built in the twelfth century by the Ganga king, Chodagangadeva, replacing an earlier structure which probably dated to the tenth century.
Long before one reaches Puri, the 214 feet (65 meters) spire of the temple can be seen towering over the countryside. This visual dominance is symbolic of the influence which the temple commands over almost every aspect of life in Puri. The huge temple compound, each side of which  measures 650 feet (some 200 meters), is surmounted with a 20 foot (6 meters) wall. Within the compound is a city, or, more accurately, a universe unto itself. With 6000 direct temple servitors, a temple kitchen which feeds 10,000 people daily (and some 25,000 on festival days), and a central deity who has become the focus of religious life throughout Odisha, the Jagannath temple is truly an institution unique in the world.</p>	
</div>
<div class="mydiv">
    <img class="myimage" src="local/konark1.jpg"/>
<h4>Konark</h4>
<p>The magnificent Sun Temple at Konark is the culmination of Odishan temple architecture, and one of the most stunning monuments of religious architecture in the world. The poet Rabindranath Tagore said of Konark that 'here the language of stone surpasses the language of man', and it is true that the experience of Konark is impossible to translate into words.
The massive structure, now in ruins, sits in solitary splendour surrounded by drifting sand. Today it is located two kilometers from the sea, but originally the ocean came almost up to its base. Until fairly recent times, in fact, the temple was close enough to the shore to be used as a navigational point by European sailors, who referred to it as the 'Black Pagoda'.
Built by King Narasimhadeva in the thirteenth century, the entire temple was designed in the shape of a colossal chariot, carrying the sun god, Surya, across the heavens. Surya has been a popular deity in India since the Vedic period and the following passages occur in a prayer to him in the Rig Veda, the earliest of sacred religious text:
</p>	
</div>
<div class="mydiv">
    <img class="myimage" src="local/chilika.jpg"/>
<h4>Chilika</h4>
<p>Just south of Puri, the sea mixes in with the 1100 sq.km inland Chilika Lake to create the largest brackish water lake in Asia. These shallow waters enclose an immense area of marshes, lowlands, and islands. There are more than 160 varieties of fish, and, in the winter season (from November through March), the area is home to hundreds of thousands of migratory birds as well.

The surrounding hills and sandy stretches abound in cheetals, blackbucks, monkeys, fishing cats, mongoose, and porcupines. At the channel meeting the sea, dolphins can be seen cavorting playfully. Snakes, turtles and lizards inhabit the surrounding beach area and wooded undergrowth.
 A number of islands dot the expanse of the lake. Nalbana Island, because of its varied flora and fauna, forms the core of the Chilika sanctuary. Kalijai Island is home to the Goddess Kalijai, venerated by the local fisher folk. This island plays host to a huge fair on 'Makar Sankranti' held annually in the month of January. The large fishing community adds flavour to the lake with their traditional colourful sail boats bobbing expertly across the water, reminiscent of the ancient maritime heritage of Odisha. In fact, the fisher folk can be persuaded to take visitors on their boats.
</p>	
</div>
<div class="mydiv">
    <img class="myimage" src="local/phurli.jpg"/>
<h4>Phurli Jharan</h4>
<p>A perennial waterfall of about 16 metres high, Phurli Jharan located around 15 km from Bhawanipatna, has a special charm of its own. The multi-coloured rainbows created by the sun-rays falling on the scattered water particles of the fall, creates a thrilling and magical ambience. The evergreen forests around provide ample opportunity for picnickers.

</p>	
</div>
<div class="mydiv">
    <img class="myimage" src="local/p2.jpg"/>
<h4>Odissi Dance</h4>
<p>Odissi is the classical dance form that originated in the ambience of the temples. It is a lyrical form of dance with its subtelety as its keynote. The intimate relationship experienced between the poetry and music in Odissi is a feature on which the aesthetics of the style is built. It is a "sculpturesque" style of dance with a harmony of line and movement, all its own.

The history of Odissi dates back to somewhere between the 8th and the 11th century, when the kings took great pride in excelling in the arts of dance and music. It is during these centuries that inscriptions referring to "Devdasis", the women who were conseciated to the worship of the deity, were carved at the Brahmeshwar temple. "Devdasis" apparently played an important part in the temple ritual and were required to perform from early evening to the bedtime of Lord Jagannath, the temple deity of Puri.

Jayadeva's "Geeta-Govinda", the bible of an Odissi dancer, written in the 12th century, has stupendous influence on the arts of Odisha. The "Ashtapadis" were marked with specific ragas and talas. Around the 15th century, during the reign of Surya Dynasty, the element of "abhinaya" or expressional dance entered Odissi. During the same time Maheshwar Mahapatra wrote his "Abhinaya Chandrika", an elaborate treatise on Odissi dance style, and today, the basic to any study of it. By the 16th century, there were three kinds of dancers in Odisha: the "Maharis" in the temples, the "Nachunis" in the royal court, and the "Gotipuas" in the gymnasiums - who performed for the public. The religious revival of the 18th century saw a return of temple patronage to the arts. But the "Maharis" were slowly disappearing and their place was being taken by the "Gotipuas", young boys dressed as girls. These boys were trained in physical culture in the "Akhadas", and it was them who preserved the basic for restructuring of the ancient dance tradition.
</p>	
</div>

<h3>Transportation:</h3>
<p align="justify">
The local transport in Bhubaneswar is safe, economical and provide a comfortable journey to the passengers. The local transport in Bhubaneswar includes a wide variety of vehicles. The local transport in Bhubaneswar includes both government and privately operated buses, auto-rickshaws, cycle rickshaws and taxis.
</p>
<p align="justify">
Please note that by 'taxis' this article describes a tourist car-and not a yellow taxi. These tourist cars are available for hire on an hourly or daily basis. From Airport, pre-paid Biju Patnaik Airport taxi service is available during flight times. You can also catch an auto-rickshaw if you have time or are looking for a cheaper choice of transport than a regular Bhubaneswar Airport taxi.
</p>
<p align="justify">
The local transport in Bhubaneswar is also provided by a large number of buses ferrying passengers from one part of Bhubaneswar city to another part. These buses are either government owned or privately held. Orissa State Road Transport Corporation (OSRTC) operate buses for local transport in Bhubaneswar . Orissa State Road Transport Corporation has a large number of buses to provide local transport in Bhubaneswar . 
</p><br>
<p align="justify">
Currently, the buses run on 17 different routes between 6 AM and 9 PM with variable frequency between 15 minutes to 30 minutes.
</p>
207/207A Nandan Kanan - Biju Patnaik International Airport<br>
306/306J KIIT University - Balakati Bazaar<br>
405 Dumduma - V.S.S Nagar<br>
504 Nakhara - Nuagaon<br>
603 Sai Temple - Kalinga Vihar<br>
333 Lingaraja Temple - Ghatikia<br>
801 Khurda - Master Canteen<br>
414 Biju Patanaik Park (CTC) - A G Square<br>
171 Baramunda - Puri<br>
324 Bidanasi (CTC) - Master Canteen<br>
315 GGP Colony - Mayfair<br>
225 KIIT University - Kalpana Square<br>
432 Jagannath Temple (Puri) - Loknath Temple (Puri)<br>
450 Talabania (Puri) - Jagannath Temple (Puri)<br>
522 Master Cantenn - Chandaka<br>
531 Master Canteen - AIIMS Bhubaneswar<br>
108 GRIDCO - Jagannath Temple (Puri)<br>


</p>
</p><br>
For any type of queries related to conference please contact <a href="mailto:info@icit2014.in">info@icit2014.in</a>
<br><br><br><br><br><br>

<!-- About CP //-->
	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
