
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
 <!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//--> 
  <!--header close-->

  <div class="menu">
 <!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
<div id="center-boxE">
<!-- About CP //-->
<center><h3>Contact Us</h3></center><br><br>

<div style="width: 40%; float:left">
 <b>Ashok K. Tripathy</b><br>
 Local Arrangement Chairs, ICIT 2014<br>
 Silicon Institute of Technology<br>
 Email:tripathy_1948@sify.com<br>
 Website: www.icit2014.in
</div>

<div style="width: 60%; float:right">
<iframe width="445" height="512" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Silicon+Institute+of+Technology,+Chandrasekharpur,+Odisha&amp;aq=0&amp;oq=Silicon+Institute+Of+Technology&amp;sll=20.352352,85.818329&amp;sspn=0.097693,0.158443&amp;ie=UTF8&amp;hq=Silicon+Institute+of+Technology,+Chandrasekharpur,+Odisha&amp;t=m&amp;ll=20.3435,85.819788&amp;spn=0.041204,0.038109&amp;z=14&amp;output=embed"></iframe>
</div>


<!-- About CP //-->
	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
