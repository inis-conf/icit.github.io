<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

        <link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
 <!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//--> 
  <!--header close-->

  <div class="menu">
 <!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
<div id="center-boxE">
<!-- About CP //-->
<table width="100%">
<tr>
<td>
<center>
<strong><h3>Model-Based Testing and Monitoring for Embedded Software</h3></strong>
<BR><BR>

Ratnesh Kumar<BR>
Dept. of Electrical & Computer Engineering<BR>
Iowa State University<BR>
Email:rkumar@iastate.edu<BR>
</center>
<BR><BR>
<strong>Abstract:</strong><BR>
<p align="justify">
In many application domains, Simulink/Stateflow serves as a platform for model-based development of the 
reactive embedded code, that interacts with its environment in real-time fashion. The talk will present 
a model-based approach for testing Simulink/Stateflow code, based on its automated translation to input-output 
extended finite automaton (I/O-EFA), followed by automated test-generation, guaranteeing user-defined code as 
well as requirements coverage, and also support for automated test-execution and error-localization. While testing 
is useful for design-time error analysis, the talk will further discuss our model-based approach for run-time error 
monitoring, detection and localization. Monitoring at system level (as opposed to software level) is necessarily stochastic, 
and a more general I/O-Stochastic Hybrid Automaton (I/O-SHA) model is used, and condition is obtained for bounded-delay 
detectability, and achieving desired levels of false-positives/-negatives.
</p>
<BR>
</td>
</tr>
<tr>
<td><strong>Speaker Biography:</strong></td>
</tr>
<tr>
<td>
<table>
 <tr>
  <td width="30%"><img src="images/ratnesh.jpg"></td>
  <td>
  <p align="justify">
Ratnesh Kumar is a Professor of Electrical & Computer Engineering at the Iowa State University, and 
prior to which he was with the ECE Dept. at the Univ. of Kentucky. He received B.Tech. in Electrical Eng. 
from Indian Institute of Technology, Kanpur (IITK) in 1987, and M.S. and Ph.D. in Electrical & Computer Engineering 
from the Univ. of Texas, Austin (UTAustin) in 1989 and 1991, respectively. Ratnesh's research interest spans sensors, 
networks, controls and software with application domains of cyberphysical (hybrid) systems, embedded and real-time systems, 
model-based software and web-services, power systems, energy harvesting, and sustainable agriculture. Ratnesh received Gold 
Medals from IITK, MCD Fellowship and Dissertation Award from UTAustin, Fellowships from NASA-Ames, Applied Research Lab-Penn 
State Univ, Idaho National Lab, and United Technologies Research Center, and several awards from NSF (including Research Initiation Award), 
DoE, ONR, General Motors, and Adobe. Ratnesh is a Fellow of the IEEE for contributions to discrete event system modeling, control, diagnosis 
and applications. Ratnesh has served on a number of editorial boards for IEEE and ACM, has been General/Program Chair and also given 
keynote talks at IEEE and ACM conferences.
  </p>
  </td>
 </tr>
</table>
</td>
</tr>
</table>
<table width="100%">
<tr>
<td>
<center>
<strong><h3>Analytical and Computer-Aided Modeling of Post-CMOS Devices in 
Emerging Novel Technologies</h3></strong>
<BR><BR>

Ashok Srivastava<BR>
Division of Electrical & Computer Engineering<BR>
School of Electrical Engineering & Computer Science<BR>
Louisiana State University, Baton Rouge, Louisiana, U.S.A. <BR>
Email:eesriv@lsu.edu<BR>
URL: <a href="https://www.ece.lsu.edu/fac/Srivastava.html" target="_blank">https://www.ece.lsu.edu/fac/Srivastava.html</a><BR>
</center>
<BR><BR>
<strong>Abstract:</strong><BR>
<p align="justify">
In search for novel technologies, no such material has aroused so much interest other than carbon nanomaterials since the discovery of one-dimensional carbon nanotube in 1991 by Iijima. The carbon nanotube (CNT) has excellent electrical, mechanical and thermal properties which has made the CNT one of the promising materials for applications in nanoelectronics and micro/nano-systems. Recent work on analytical modeling equations describing the current transport in carbon nanotube field effect transistors compatible with VLSI CAD tools such as Cadence/Verilog-AMS and interconnects will be presented for use in design of emerging logic devices similar to CMOS design style, molecular sensing and bio-electronics circuits. The two-dimensional material graphene has demonstrated exceptional electronic properties such as the current density 2-3 orders of magnitude higher than that of the copper interconnect used in current silicon technologies, and exhibited potential for energy harvesting devices, displays, sensors and storage cell batteries.  Recent work on both analytical and computer-aided modeling of novel graphene transistors for RF, and ultra-high performance integrated circuit design will be presented.
</p>
<BR>
</td>
</tr>
<tr>
<td><strong>Speaker Biography:</strong></td>
</tr>
<tr>
<td>
<table>
 <tr>
  <td width="30%"><img src="images/ashok.jpg"></td>
  <td>
  <p align="justify">
Dr. Ashok Srivastava received his M.Sc. (Physics) degree with specialization in Advanced Electronics from University of Lucknow, India, in 1968. He obtained M.Tech. and Ph.D. degrees in Solid State Physics and Semiconductor Electronics area from Indian Institute of Technology, Delhi in 1970 and 1975, respectively. He joined the Department of Electrical & Computer Engineering of Louisiana State University, Baton Rouge in 1990 as an Associate Professor and currently is Wilbur D. and Camille V. Fugler, Jr., Professor of Engineering. In year 2011, he held visiting appointments at the Institute of Electrical Engineering NanoLab, Swiss Federal Institute of Technology (EPFL), Lausanne, Switzerland; Katholiek Universiteit/Inter-university Microelectronics Center (IMEC), Leuven, Belgium; Indian Institute of Information Technology (IIIT), Allahabad; and in year 2001 at the Philips Research Laboratory, Eindhoven, The Netherlands. His other past appointments include Central Electronics Engineering Research Institute, Pilani, India (1975-84), Birla Institute of Technology and Science, Pilani, India (1975); North Carolina State University, Raleigh (1985-86); State University of New York, New Paltz (1986-90); University of Cincinnati, Cincinnati (1979); University of Arizona, Tucson (1979-80), Kirtland Air Force Base, New Mexico (Summer 1996); and Jet Propulsion Laboratory/California Institute of Technology, Pasadena (Summer 2004).
</p>
<p align="justify">
He is the recipient of the prestigious 1979-1980 UNESCO Fellowship Award and Dean College of Engineering 1994 Teaching Award, Louisiana State University. He has 1 US patent and several technology disclosures. He is the author of more than 150 technical papers, including conference proceedings book chapters and a book on Nanoelectronics. He has graduated 40 students in Electrical Engineering including 7 PhDs who are employed by academic institutions, VLSI chip design and semiconductor companies across the globe. He has also supervised many MS (EE) students with non-thesis and project options. He has many professional presentations including invited talks. He is reviewer of numerous international journal papers and books, examiner of overseas PhD dissertations and has served on NSF review panels and advisory board of NSF CREST and RISE of one of the US universities and program committees of international conferences. He serves on the Editorial Review Board of the<i> International Journal of Nanotechnology and Molecular Computation (IJNMC), Modeling and Numerical Simulation of Material Science (MNSMS), Journal of Material Science and Chemical Engineering (JMSCE), The Scientific World Journal (Electronics)</i> and is Editor-in-Chief of the Journal of Sensor Technology published by the Scientific Research, USA. He has been awarded grants and contracts from federal, state, industry and foundations. He is a Senior Member of IEEE, Electron Devices, Circuits and Systems, and Solid-State Circuits Societies, Nanotechnology Council, and Member of SPIE and ASEE. His current research interests are in Low Power VLSI Circuit Design and Testability (Digital, Analog and Mixed-Signal); Noise in Devices and VLSI Circuits; Nanoelectronics (Non-classical Device Electronics with focus on Carbon Nanotube, Graphene and other 2D materials for Integration with Sub-nanometer CMOS Technology Nodes and Emerging Integrated Electronics). 
  </p>
  </td>
 </tr>
</table>
</td>
</tr>
</table>
<!-- About CP //-->
	
    </div>
  </div>
  <!--menu-->
  <div class="footer">
   <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
