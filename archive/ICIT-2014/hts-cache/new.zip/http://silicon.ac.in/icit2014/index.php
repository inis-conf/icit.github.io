<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta name="description" content="Conference: International Conference on Information Technology 2014(ICIT 2014), Date: Dec.22 - Dec.24, 2014, Place: Silicon Institute of Technology, Bhubaneswar Orissa India">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Pragma" content="No-Cache">
<meta http-equiv="Expires" content="now"><title>ICIT 2014</title>
<title>ICIT - 2014 @ Silicon Institute of Technology, Bhubaneswar Odisha India</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<!--[if IE 9 ]> 
<link href="ie9.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 8 ]> 
<link href="ie8.css" rel="stylesheet" type="text/css" />
   <![endif]-->

<link rel="stylesheet" href="tinyscrollbar.css" type="text/css" media="screen"/>

<script type="text/javascript" src="jquery.tinyscrollbar.js"></script>
<script type="text/javascript">
            $(document).ready(function(){
                $('#scrollbar1').tinyscrollbar();
            });
        </script> 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50188997-1', 'icit2014.in');
  ga('send', 'pageview');

</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js?ver=1.4.2"></script>
<script type="text/javascript" src="slidedeck.jquery.js"></script>
        <style type="text/css">
	
		/*::::::::::::::: SLIDEDECK SLIDE STYLE (BEGIN) :::::::::::::::*/
		
		#slidedeck_frame {
			width: 730px;
			height: 273px;
			position: relative;
			overflow:hidden;
		}
		
		dl.slidedeck {
			position: relative;
			width: 100%;
			height: 100%;
			margin: 0;
			padding: 0;
			float: right;
			background: #ccc;
		}
		
		dl.slidedeck > dd {
			position: relative;
			margin: 0;
			border-bottom: 1px solid #ccc;
			overflow: hidden;
		}
		
		dl.slidedeck dd.slide_1{
			background: url('images/slide100.jpg') center center no-repeat;
		}
		
		dl.slidedeck dd.slide_2{
			background: url('images/slide-2.jpg') center center no-repeat;
		}
		
		dl.slidedeck dd.slide_3{
			background: url('images/slide-1.jpg') center center no-repeat;
		}
		
		dl.slidedeck dd.slide_4{
			background: url('images/slide-3.jpg') center center no-repeat;
		}
		
		dl.slidedeck dd.slide_5{
			background: url('images/slide-4.jpg') center center no-repeat;
		}
		
		/*::::::::::::::: SLIDEDECK SLIDE STYLE (END) :::::::::::::::*/
		
		/*::::::::::::::: CAPTION STYLE (BEGIN) :::::::::::::::*/
		
		div.caption{
			background: #000;
			background: rgba(0, 0, 0, 0.7);
			width: 100%;
			padding: 10px 0 25px;
			color: #ababab;
			position: absolute;
			bottom: 0px;
		}
		
		div.caption h3, div.caption p, div.title h3, div.title p{
			margin:0;
			padding:0 10px;
			font-weight:normal;
		}
		
		div.caption h3{
			font-size: 12px;
			font-weight:normal;
		}
		
		/*::::::::::::::: CAPTION STYLE (END) :::::::::::::::*/
		
		/*::::::::::::::: VERTICAL NAVIGATION STYLE (BEGIN) :::::::::::::::*/
		
		ul.slidedeckNav{
			position:absolute;
			bottom: 1px;
			margin: 0;
			padding: 0;
			list-style:none;
			z-index:10;
			right: 25px;
			font-size: 11px;
			line-height: 11px;
		}
		
		ul.slidedeckNav li{
			display:block;
			float:left;
			margin: 0;
			padding: 0;
		}
		
		ul.slidedeckNav li a{
			display:block;
			position:relative;
			overflow:hidden;
			width:15px;
			padding: 6px 3px;
			text-align: center;
			margin-left: 5px;
			-webkit-border-radius: 3px;
			-moz-border-radius: 3px;
			border-radius: 3px;
			color: #fff;
			text-decoration:none;
		}
		
		ul.slidedeckNav li.active a{
			background: #555;
		}
		
		/*::::::::::::::: VERTICAL NAVIGATION STYLE (END) :::::::::::::::*/
		
		</style>		
</head>

<body>
<div class="container">
  <div class="topBanner">	
<!-- Header Include//-->
  <div class="header">
    <div id="nav">
      <ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Conference Details</a>
			<ul>
				<li><a href="about.php">About ICIT</a></li>
				<li><a href="org.php">Organizing Committee</a></li>
				<li><a href="prog.php">Program Committee</a></li>
				
			</ul>	
		</li>
        <li><a href="cfp.php">Call For Papers</a></li>
		<li><a href="submission.php">Submission</a></li>
<li><a href="keynote.php">Speaker Details</a>
			<ul>
				<li><a href="plenary.php">Plenary Talk</a></li>
				<li><a href="keynote.php">Keynote</a></li>
			</ul>
</li>
<!--		
<li><a href="invited.php">Invited Speakers</a>
			<ul>
				<li><a href="keynote.php">Plenary/Keynote Speakers</a></li>
			</ul>		
</li> //-->
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="regd.php">Registration</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="#">Travel</a>
			<ul>
				<li><a href="route.php">Reaching the City</a></li>
				<li><a href="visainfo.php">VISA Information</a></li>
			</ul>		
		</li>
		<li><a href="contacts.php">Contacts</a></li>
      </ul>
    </div>
   
  </div>
 </div> 
  <!--header close--><!-- Header Include//-->
  <div class="banner">
    <div class="banner-img">
		<div id="slidedeck_frame">
			<dl class="slidedeck">
				<dt>Slide 1</dt>
				<dd>
                	<div class="caption">
                    	<h3>Bhubaneswar, Temple City</h3>
                    </div>
                </dd>			
				<dt>Slide 2</dt>
				<dd>
                	<div class="caption">
                    	<h3>Shri Shri Jagannath Mahaprabhu</h3>
                    </div>
                </dd>
				<dt>Slide 3</dt>
				<dd>
                	<div class="caption">
                    	<h3>Sun Temple, Konark</h3>
                    </div>
                </dd>
				<dt>Slide 4</dt>
				<dd>
                	<div class="caption">
                    	<h3>Chilka Lake</h3>
                    </div>
                </dd>
				<dt>Slide 5</dt>
				<dd>
                	<div class="caption">
                    	<h3>Buddhist Shanti Stupa Dhauli</h3>
                    </div>
                </dd>
			</dl>
		</div>
		
		<script type="text/javascript">
        /**
         * Script for handling goTo's (numbered navigation) and next/prev navigation
         */ 
		var SlideDeckAssistant = {
			innerSlideCount: 0,
			/** prevSlide, nextSlide and goToSlide are all custom functions to control progress of the SlideDeck */
			prevSlide: function(theIndex){
				SlideDeckAssistant.goToSlide(theIndex - 1);
			},
			nextSlide: function(theIndex){
				SlideDeckAssistant.goToSlide(theIndex + 1);
			},
			goToSlide: function(theIndex){        
				$('ul.slidedeckNav li.num').removeClass('active');
				$('ul.slidedeckNav li.num:eq('+ theIndex +')').addClass('active');
				myDeck.goTo(theIndex+1);
				if((theIndex + 1) == SlideDeckAssistant.innerSlideCount){
					// disable the next button
					$('ul.slidedeckNav .next').addClass('disabled');
					$('ul.slidedeckNav .prev').removeClass('disabled');
				}else if((theIndex + 1) == 1){
					// disable the previous button
					$('ul.slidedeckNav .next').removeClass('disabled');
					$('ul.slidedeckNav .prev').addClass('disabled');
				}else{
					// enable both next/previous buttons
					$('ul.slidedeckNav .next, ul.slidedeckNav .prev').removeClass('disabled');
				}
			},
			init: function(){
				SlideDeckAssistant.innerSlideCount = $('#slidedeck_frame dl.slidedeck dd').length;
				/** Store number of slides in SlideDeck */
				$('#slidedeck_frame').append('<ul class="slidedeckNav"><\/ul>');
				// create navigation element
				$('ul.slidedeckNav').prepend('<li class="prev"><a href="#prev">&laquo;<\/a><\/li>');
				// add previous button
				for (i=0 ; i < SlideDeckAssistant.innerSlideCount ; i++ ) {
					$('ul.slidedeckNav').append('<li class="num"><a href="goto#' + (i+1) + '">' + (i+1) + '<\/a><\/li>');
				}
				// add numbered navigation buttons for each slide
				$('ul.slidedeckNav').append('<li class="next"><a href="#next">&raquo;<\/a><\/li>');
				// add next button
				$('ul.slidedeckNav li.num:first').addClass('active');
				$('ul.slidedeckNav li.num.prev').addClass('disabled');
				$('ul.slidedeckNav li.num a').click(function(e){
					e.preventDefault();
					var theIndex = $('ul.slidedeckNav li.num a').index($(this));
					SlideDeckAssistant.goToSlide(theIndex);
					return false;
				});
				// assign click function to numbered navigation buttons
				$('ul.slidedeckNav li.prev a').click(function(e){
					e.preventDefault();
					if($(this).parent('li').hasClass('disabled')){
						return false;
					}else{
						var theIndex = $('ul.slidedeckNav li').index($('ul.slidedeckNav li.active')) - 1;
						SlideDeckAssistant.prevSlide(theIndex);
					}
					return false;
				});
				// assign click function to previous button
				$('ul.slidedeckNav li.next a').click(function(e){
					e.preventDefault();
					if($(this).parent('li').hasClass('disabled')){
						return false;
					}
					else{
						var theIndex = $('ul.slidedeckNav li').index($('ul.slidedeckNav li.active')) - 1;
						SlideDeckAssistant.nextSlide(theIndex);
					}
					return false;
				});
				// assign click function to next button
		}
		};
		
		$(document).ready(function(){
			SlideDeckAssistant.init();
		});
			
		/** Initiate the SlideDeck */
		var myDeck = $('#slidedeck_frame dl.slidedeck').slidedeck({
			hideSpines: true,
            autoPlay: true,
            cycle: true,
            /**
             * The complete function is executed after each slide animation.
             * here we are using it to upate the navigation dots.
             */
            complete: function(deck){
				$('#slidedeck_frame .slidedeckNav li').removeClass('active');
				$('#slidedeck_frame .slidedeckNav li.num:eq('+ ( deck.current - 1 ) +')').addClass('active');
				/** Update current slide indicator after each slide animation completes */
            }
		})
			
			
		</script>
	    <!-- Help support SlideDeck! Place this noscript tag on your page when you deploy a SlideDeck to provide a link back! -->
	
    </div>
    
    <div class="right-side">
<!--
	  <h4>Technical Co-sponsorship</h4>
	  <center><img src="images/IEEE_large.png"></center>
//-->
      <h4>ICIT Updates</h4>
      <h5>International Conference on Information Technology</h5>
      <span>22nd-24th, Dec, 2014</span>
      <h5>ICIT 2014 Student Research Symposium</h5>    
      <span>23nd-24th, Dec, 2014<a href="http://www.icit2014.in/student/"><font color="#F37913">...More</font></a></span>
	<h5><a href="Hotel_Details(ICIT-2014).pdf" target="_blank"><font color="white">Hotel Details&nbsp;<img src="http://www.silicon.ac.in/sitbbsr/assets/img/new_icon_animated.gif"></font></a></h5>
    </div>
  </div>
  <!--banner close-->
  <div class="menu">
<!-- left mneu Include//-->
    <div class="left-box">
      <p class="ptext">Information</p>
      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
		<li><a href="prog.php">Program Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>
		<li><a href="schedule.php">Programme Schedule</a></li>
		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>
        <li><a href="index.php#sponsor">Sponsors</a></li>
<li><a href="https://sites.google.com/site/citconference/">Past ICITs</a></li>

       
      </ul>
      <div class="media-icon">
        <h4>Venue</h4>
        <img src="images/location.jpg">
      </div>
    </div><!-- left mneu Include//-->	
	
    <div class="center-box">
      <h3>WELCOME to </h3>
      <p class="center-txt">13<sup>th</sup>&nbsp;&nbsp;International Conference on Information Technology</p>
      <p align="justify">
<!--
	  ICIT (International Conference on Information Technology) is a premier 
	  international conference and forum for high quality research in the area of 
	  Information Technology. ICIT2014 is organized by Silicon Institute of Technology 
	  (<a href="http://www.silicon.ac.in">http://www.silicon.ac.in</a>) in collaboration with Orissa IT Society (<a href="http://www.oits.org">http://www.oits.org</a>) and
	 technical sponsor from IEEE Kolkata Section.
	  This will be held at Bhubaneswar, India from 22<sup>nd</sup>-24<sup>th</sup> December 2014. 
	  Researchers, developers, and practitioners 
	  from academia and industry are invited to present their research findings on 
	  various topics related to Information Technology and its Applications. 
	  All accepted papers after peer-review will be published by IEEE-CS-CPS and will be indexed in IEEE Xplore.
//-->	
  ICIT (International Conference on Information Technology) is a premier 
	  international conference and forum for high quality research in the area of 
	  Information Technology. ICIT2014 is organized by Silicon Institute of Technology 
	  (<a href="http://www.silicon.ac.in">http://www.silicon.ac.in</a>) in collaboration with Orissa IT Society (<a href="http://www.oits.org">http://www.oits.org</a>).
	  This will be held at Bhubaneswar, India from 22<sup>nd</sup>-24<sup>th</sup> December 2014. 
	  Researchers, developers, and practitioners 
	  from academia and industry are invited to present their research findings on 
	  various topics related to Information Technology and its Applications. 
	  
      </p>
	  <BR>
          <div>
    <img src="images/spon.jpg">
	<a name="sponsor">&nbsp;</a>
    </div>
    </div>

    <div class="right-box">
      <div class="e-form">
        <h4>Important Dates</h4>
<dl>
		<dt><b>Paper Submission:</b></dt><dd><strike> 25<sup>th</sup> June, 2014</strike><BR>
15<sup>th</sup> July, 2014
</dd>
		<dt><b>Authors Notification:</b></dt> <dd>22<sup>nd</sup> Sept, 2014</dd>
		<dt><b>Camera Ready and Registration:</b></dt><dd>24<sup>th</sup> Oct (Friday), 2014(3 p.m. PST on Friday)&nbsp;&nbsp;<img src="http://www.silicon.ac.in/sitbbsr/assets/img/new_icon_animated.gif"></dd><BR>
		<dt><b>Conference Date:</b></dt><dd> 22<sup>nd</sup> - 24<sup>th</sup> Dec, 2014</dd>
</dl>
      </div>
		<div class="testimonials">
        <h5></h5>
		</div>
  
   
      <div class="news-letter">
        <h4>Viewers</h4>
		<div class="icons">
<script>(function(){var D=document,W=window;function A(){if(W.plesk){return;}W.plesk=1;if(D.getElementsByTagName){var S=D.getElementsByTagName("head")[0].appendChild(D.createElement("script"));S.setAttribute("src","http://promo.parallels.com/js/promo.plesk.js")}}if(D.addEventListener){D.addEventListener("DOMContentLoaded",A,false)}/*@cc_on D.write("\x3cscript id=\"_IE_onload\" defer=\"defer\" src=\"javascript:void(0)\">\x3c\/script>");(D.getElementById("_IE_onload")).onreadystatechange=function(){if(this.readyState=="complete"){A()}};@*/if(/WebK/i.test(navigator.userAgent)){var C=setInterval(function(){if(/loaded|complete/.test(D.readyState)){clearInterval(C);A()}},10)}W[/*@cc_on !@*/0?'attachEvent':'addEventListener'](/*@cc_on 'on'+@*/'load',A,false)})()</script>
<script type="text/javascript" src="http://jd.revolvermaps.com/2/2.js?i=37rz4j2tfr5&amp;m=0&amp;s=130&amp;c=ff0000&amp;t=1" async="async"></script>

</div>
      </div>
    </div>
  </div>
  <!--menu-->
  <div class="footer">
  <!--   footermenu include                  //-->
    <div class="left-footer">
      <ul>
        <li><a href="stats.php">&copy;</a> 2014 -</li>
        <li><a href="http://www.silicon.ac.in">www.silicon.ac.in</a></li>
      </ul>
    </div>
    <div class="right-footer">

      <ul>
        <li><a href="about.php">About ICIT</a></li>
        <li><a href="org.php">Organizing Committee</a></li>
        <li><a href="cfp.php">Call for Papers</a></li>
		<li><a href="dates.php">Important Dates</a></li>

		<li><a href="cp.php">Conference Proceeding</a></li>
        <li><a href="regd.php">Registration Details</a></li>
        <li><a href="localinfo.php">Local Information</a></li>

      </ul>


    </div>  <!--   footermenu include                  //-->
  </div>
</div>
<!--container close-->
</body>
</html>
